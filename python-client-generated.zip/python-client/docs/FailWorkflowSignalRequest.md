# FailWorkflowSignalRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **str** | Externally provided Error of a signalling action. | 
**cause** | **str** | Externally provided Cause of a failed signalling action. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


