# SucceedWorkflowSignalRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | **object** | External result of a successful signal. Must resolve to a JSON value. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


